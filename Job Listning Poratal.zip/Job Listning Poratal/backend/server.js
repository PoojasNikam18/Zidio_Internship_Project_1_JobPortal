import app from "./app.js";
import cloudinary from "cloudinary";
import dotenv from "dotenv";
import cors from "cors";  // Import cors package


// Load environment variables from .env file (if exists)
dotenv.config();

// Validate environment variables
if (!process.env.CLOUDINARY_CLIENT_NAME || !process.env.CLOUDINARY_CLIENT_API || !process.env.CLOUDINARY_CLIENT_SECRET) {
  console.error("Cloudinary configuration is missing. Please set the environment variables.");
  process.exit(1); // Exit the application if Cloudinary config is not available
}

if (!process.env.PORT) {
  console.error("PORT is not defined. Please set the PORT environment variable.");
  process.exit(1);
}

// Cloudinary configuration
cloudinary.v2.config({
  cloud_name: process.env.CLOUDINARY_CLIENT_NAME,
  api_key: process.env.CLOUDINARY_CLIENT_API,
  api_secret: process.env.CLOUDINARY_CLIENT_SECRET,
});

// Start server
app.listen(process.env.PORT, () => {
  console.log(`Server running at port ${process.env.PORT}`);
});

// Graceful shutdown handling
process.on('SIGINT', () => {
  console.log('Received SIGINT. Closing server...');
  app.close(() => {
    console.log('Server closed gracefully');
    process.exit(0); // Exit the process
  });
});
